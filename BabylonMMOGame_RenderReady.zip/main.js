
const canvas = document.getElementById("renderCanvas");
const engine = new BABYLON.Engine(canvas, true);
let scene;
let player;
let nicknameLabel;
let inputVector = BABYLON.Vector3.Zero();

document.getElementById("startButton").addEventListener("click", () => {
    document.getElementById("characterSelect").style.display = "none";
    document.getElementById("nicknameInput").style.display = "none";
    document.getElementById("startButton").style.display = "none";
    createGame();
});

function createGame() {
    scene = new BABYLON.Scene(engine);
    const camera = new BABYLON.ArcRotateCamera("ArcRotateCamera", Math.PI / 2, Math.PI / 3, 10, BABYLON.Vector3.Zero(), scene);
    camera.attachControl(canvas, true);
    camera.lowerRadiusLimit = 10;
    camera.upperRadiusLimit = 10;
    camera.wheelPrecision = 1000;

    const light = new BABYLON.HemisphericLight("light", new BABYLON.Vector3(0, 1, 0), scene);

    const ground = BABYLON.MeshBuilder.CreateGround("ground", { width: 200, height: 200 }, scene);
    const groundMat = new BABYLON.StandardMaterial("groundMat", scene);
    groundMat.diffuseColor = new BABYLON.Color3(0.2, 0.4, 0.2);
    ground.material = groundMat;

    const charIndex = parseInt(document.getElementById("characterSelect").value);
    player = BABYLON.MeshBuilder.CreateBox("player", { size: 2 }, scene);
    player.position.y = 1;

    const dynamicTexture = new BABYLON.DynamicTexture("dynamic texture", {width:512, height:256}, scene);
    const nickname = document.getElementById("nicknameInput").value || "Player";
    dynamicTexture.drawText(nickname, null, 140, "bold 80px Arial", "white", "transparent");
    const plane = BABYLON.MeshBuilder.CreatePlane("textPlane", {width:5, height:2}, scene);
    plane.position = new BABYLON.Vector3(0, 3, 0);
    plane.parent = player;
    const planeMat = new BABYLON.StandardMaterial("textMat", scene);
    planeMat.diffuseTexture = dynamicTexture;
    planeMat.emissiveColor = BABYLON.Color3.White();
    plane.material = planeMat;

    camera.target = player;

    const joystickZone = document.createElement("div");
    joystickZone.style.position = "absolute";
    joystickZone.style.left = "0";
    joystickZone.style.bottom = "0";
    joystickZone.style.width = "200px";
    joystickZone.style.height = "200px";
    document.body.appendChild(joystickZone);

    const joystick = nipplejs.create({
        zone: joystickZone,
        mode: "static",
        position: { left: "100px", bottom: "100px" },
        color: "white"
    });

    joystick.on("move", (evt, data) => {
        const distance = data.distance / 60;
        const angle = data.angle.radian;
        inputVector = new BABYLON.Vector3(Math.cos(angle) * distance, 0, Math.sin(angle) * distance);
    });

    joystick.on("end", () => {
        inputVector = BABYLON.Vector3.Zero();
    });

    scene.onBeforeRenderObservable.add(() => {
        player.moveWithCollisions(inputVector);
        camera.target = player.position;
    });
}

engine.runRenderLoop(() => { if (scene) scene.render(); });
window.addEventListener("resize", () => engine.resize());
